/*******************************************************************************
* File Name: ext_p1cfg.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_ext_p1cfg_H)
#define CY_AMUX_ext_p1cfg_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void ext_p1cfg_Start(void) ;
#define ext_p1cfg_Init() ext_p1cfg_Start()
void ext_p1cfg_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void ext_p1cfg_Stop(void); */
/* void ext_p1cfg_Select(uint8 channel); */
/* void ext_p1cfg_Connect(uint8 channel); */
/* void ext_p1cfg_Disconnect(uint8 channel); */
/* void ext_p1cfg_DisconnectAll(void) */


/***************************************
*         Parameter Constants
***************************************/

#define ext_p1cfg_CHANNELS  1u
#define ext_p1cfg_MUXTYPE   1
#define ext_p1cfg_ATMOSTONE 0

/***************************************
*             API Constants
***************************************/

#define ext_p1cfg_NULL_CHANNEL 0xFFu
#define ext_p1cfg_MUX_SINGLE   1
#define ext_p1cfg_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if ext_p1cfg_MUXTYPE == ext_p1cfg_MUX_SINGLE
# if !ext_p1cfg_ATMOSTONE
#  define ext_p1cfg_Connect(channel) ext_p1cfg_Set(channel)
# endif
# define ext_p1cfg_Disconnect(channel) ext_p1cfg_Unset(channel)
#else
# if !ext_p1cfg_ATMOSTONE
void ext_p1cfg_Connect(uint8 channel) ;
# endif
void ext_p1cfg_Disconnect(uint8 channel) ;
#endif

#if ext_p1cfg_ATMOSTONE
# define ext_p1cfg_Stop() ext_p1cfg_DisconnectAll()
# define ext_p1cfg_Select(channel) ext_p1cfg_FastSelect(channel)
void ext_p1cfg_DisconnectAll(void) ;
#else
# define ext_p1cfg_Stop() ext_p1cfg_Start()
void ext_p1cfg_Select(uint8 channel) ;
# define ext_p1cfg_DisconnectAll() ext_p1cfg_Start()
#endif

#endif /* CY_AMUX_ext_p1cfg_H */


/* [] END OF FILE */
