/*******************************************************************************
* File Name: ext_mode.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_ext_mode_H)
#define CY_AMUX_ext_mode_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void ext_mode_Start(void) ;
#define ext_mode_Init() ext_mode_Start()
void ext_mode_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void ext_mode_Stop(void); */
/* void ext_mode_Select(uint8 channel); */
/* void ext_mode_Connect(uint8 channel); */
/* void ext_mode_Disconnect(uint8 channel); */
/* void ext_mode_DisconnectAll(void) */


/***************************************
*         Parameter Constants
***************************************/

#define ext_mode_CHANNELS  1u
#define ext_mode_MUXTYPE   1
#define ext_mode_ATMOSTONE 0

/***************************************
*             API Constants
***************************************/

#define ext_mode_NULL_CHANNEL 0xFFu
#define ext_mode_MUX_SINGLE   1
#define ext_mode_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if ext_mode_MUXTYPE == ext_mode_MUX_SINGLE
# if !ext_mode_ATMOSTONE
#  define ext_mode_Connect(channel) ext_mode_Set(channel)
# endif
# define ext_mode_Disconnect(channel) ext_mode_Unset(channel)
#else
# if !ext_mode_ATMOSTONE
void ext_mode_Connect(uint8 channel) ;
# endif
void ext_mode_Disconnect(uint8 channel) ;
#endif

#if ext_mode_ATMOSTONE
# define ext_mode_Stop() ext_mode_DisconnectAll()
# define ext_mode_Select(channel) ext_mode_FastSelect(channel)
void ext_mode_DisconnectAll(void) ;
#else
# define ext_mode_Stop() ext_mode_Start()
void ext_mode_Select(uint8 channel) ;
# define ext_mode_DisconnectAll() ext_mode_Start()
#endif

#endif /* CY_AMUX_ext_mode_H */


/* [] END OF FILE */
