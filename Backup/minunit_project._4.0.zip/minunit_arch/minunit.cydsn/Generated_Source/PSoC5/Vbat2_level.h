/*******************************************************************************
* File Name: Vbat2_level.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vbat2_level_H) /* Pins Vbat2_level_H */
#define CY_PINS_Vbat2_level_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Vbat2_level_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Vbat2_level__PORT == 15 && ((Vbat2_level__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Vbat2_level_Write(uint8 value);
void    Vbat2_level_SetDriveMode(uint8 mode);
uint8   Vbat2_level_ReadDataReg(void);
uint8   Vbat2_level_Read(void);
void    Vbat2_level_SetInterruptMode(uint16 position, uint16 mode);
uint8   Vbat2_level_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Vbat2_level_SetDriveMode() function.
     *  @{
     */
        #define Vbat2_level_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Vbat2_level_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Vbat2_level_DM_RES_UP          PIN_DM_RES_UP
        #define Vbat2_level_DM_RES_DWN         PIN_DM_RES_DWN
        #define Vbat2_level_DM_OD_LO           PIN_DM_OD_LO
        #define Vbat2_level_DM_OD_HI           PIN_DM_OD_HI
        #define Vbat2_level_DM_STRONG          PIN_DM_STRONG
        #define Vbat2_level_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Vbat2_level_MASK               Vbat2_level__MASK
#define Vbat2_level_SHIFT              Vbat2_level__SHIFT
#define Vbat2_level_WIDTH              1u

/* Interrupt constants */
#if defined(Vbat2_level__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Vbat2_level_SetInterruptMode() function.
     *  @{
     */
        #define Vbat2_level_INTR_NONE      (uint16)(0x0000u)
        #define Vbat2_level_INTR_RISING    (uint16)(0x0001u)
        #define Vbat2_level_INTR_FALLING   (uint16)(0x0002u)
        #define Vbat2_level_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Vbat2_level_INTR_MASK      (0x01u) 
#endif /* (Vbat2_level__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Vbat2_level_PS                     (* (reg8 *) Vbat2_level__PS)
/* Data Register */
#define Vbat2_level_DR                     (* (reg8 *) Vbat2_level__DR)
/* Port Number */
#define Vbat2_level_PRT_NUM                (* (reg8 *) Vbat2_level__PRT) 
/* Connect to Analog Globals */                                                  
#define Vbat2_level_AG                     (* (reg8 *) Vbat2_level__AG)                       
/* Analog MUX bux enable */
#define Vbat2_level_AMUX                   (* (reg8 *) Vbat2_level__AMUX) 
/* Bidirectional Enable */                                                        
#define Vbat2_level_BIE                    (* (reg8 *) Vbat2_level__BIE)
/* Bit-mask for Aliased Register Access */
#define Vbat2_level_BIT_MASK               (* (reg8 *) Vbat2_level__BIT_MASK)
/* Bypass Enable */
#define Vbat2_level_BYP                    (* (reg8 *) Vbat2_level__BYP)
/* Port wide control signals */                                                   
#define Vbat2_level_CTL                    (* (reg8 *) Vbat2_level__CTL)
/* Drive Modes */
#define Vbat2_level_DM0                    (* (reg8 *) Vbat2_level__DM0) 
#define Vbat2_level_DM1                    (* (reg8 *) Vbat2_level__DM1)
#define Vbat2_level_DM2                    (* (reg8 *) Vbat2_level__DM2) 
/* Input Buffer Disable Override */
#define Vbat2_level_INP_DIS                (* (reg8 *) Vbat2_level__INP_DIS)
/* LCD Common or Segment Drive */
#define Vbat2_level_LCD_COM_SEG            (* (reg8 *) Vbat2_level__LCD_COM_SEG)
/* Enable Segment LCD */
#define Vbat2_level_LCD_EN                 (* (reg8 *) Vbat2_level__LCD_EN)
/* Slew Rate Control */
#define Vbat2_level_SLW                    (* (reg8 *) Vbat2_level__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Vbat2_level_PRTDSI__CAPS_SEL       (* (reg8 *) Vbat2_level__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Vbat2_level_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Vbat2_level__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Vbat2_level_PRTDSI__OE_SEL0        (* (reg8 *) Vbat2_level__PRTDSI__OE_SEL0) 
#define Vbat2_level_PRTDSI__OE_SEL1        (* (reg8 *) Vbat2_level__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Vbat2_level_PRTDSI__OUT_SEL0       (* (reg8 *) Vbat2_level__PRTDSI__OUT_SEL0) 
#define Vbat2_level_PRTDSI__OUT_SEL1       (* (reg8 *) Vbat2_level__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Vbat2_level_PRTDSI__SYNC_OUT       (* (reg8 *) Vbat2_level__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Vbat2_level__SIO_CFG)
    #define Vbat2_level_SIO_HYST_EN        (* (reg8 *) Vbat2_level__SIO_HYST_EN)
    #define Vbat2_level_SIO_REG_HIFREQ     (* (reg8 *) Vbat2_level__SIO_REG_HIFREQ)
    #define Vbat2_level_SIO_CFG            (* (reg8 *) Vbat2_level__SIO_CFG)
    #define Vbat2_level_SIO_DIFF           (* (reg8 *) Vbat2_level__SIO_DIFF)
#endif /* (Vbat2_level__SIO_CFG) */

/* Interrupt Registers */
#if defined(Vbat2_level__INTSTAT)
    #define Vbat2_level_INTSTAT            (* (reg8 *) Vbat2_level__INTSTAT)
    #define Vbat2_level_SNAP               (* (reg8 *) Vbat2_level__SNAP)
    
	#define Vbat2_level_0_INTTYPE_REG 		(* (reg8 *) Vbat2_level__0__INTTYPE)
#endif /* (Vbat2_level__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Vbat2_level_H */


/* [] END OF FILE */
