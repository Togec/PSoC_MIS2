/*******************************************************************************
* File Name: PulseCounter.c  
* Version 3.0
*
*  Description:
*     The Counter component consists of a 8, 16, 24 or 32-bit counter with
*     a selectable period between 2 and 2^Width - 1.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "PulseCounter.h"

uint8 PulseCounter_initVar = 0u;


/*******************************************************************************
* Function Name: PulseCounter_Init
********************************************************************************
* Summary:
*     Initialize to the schematic state
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void PulseCounter_Init(void) 
{
        #if (!PulseCounter_UsingFixedFunction && !PulseCounter_ControlRegRemoved)
            uint8 ctrl;
        #endif /* (!PulseCounter_UsingFixedFunction && !PulseCounter_ControlRegRemoved) */
        
        #if(!PulseCounter_UsingFixedFunction) 
            /* Interrupt State Backup for Critical Region*/
            uint8 PulseCounter_interruptState;
        #endif /* (!PulseCounter_UsingFixedFunction) */
        
        #if (PulseCounter_UsingFixedFunction)
            /* Clear all bits but the enable bit (if it's already set for Timer operation */
            PulseCounter_CONTROL &= PulseCounter_CTRL_ENABLE;
            
            /* Clear the mode bits for continuous run mode */
            #if (CY_PSOC5A)
                PulseCounter_CONTROL2 &= ((uint8)(~PulseCounter_CTRL_MODE_MASK));
            #endif /* (CY_PSOC5A) */
            #if (CY_PSOC3 || CY_PSOC5LP)
                PulseCounter_CONTROL3 &= ((uint8)(~PulseCounter_CTRL_MODE_MASK));                
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            /* Check if One Shot mode is enabled i.e. RunMode !=0*/
            #if (PulseCounter_RunModeUsed != 0x0u)
                /* Set 3rd bit of Control register to enable one shot mode */
                PulseCounter_CONTROL |= PulseCounter_ONESHOT;
            #endif /* (PulseCounter_RunModeUsed != 0x0u) */
            
            /* Set the IRQ to use the status register interrupts */
            PulseCounter_CONTROL2 |= PulseCounter_CTRL2_IRQ_SEL;
            
            /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
            PulseCounter_RT1 &= ((uint8)(~PulseCounter_RT1_MASK));
            PulseCounter_RT1 |= PulseCounter_SYNC;     
                    
            /*Enable DSI Sync all all inputs of the Timer*/
            PulseCounter_RT1 &= ((uint8)(~PulseCounter_SYNCDSI_MASK));
            PulseCounter_RT1 |= PulseCounter_SYNCDSI_EN;

        #else
            #if(!PulseCounter_ControlRegRemoved)
            /* Set the default compare mode defined in the parameter */
            ctrl = PulseCounter_CONTROL & ((uint8)(~PulseCounter_CTRL_CMPMODE_MASK));
            PulseCounter_CONTROL = ctrl | PulseCounter_DEFAULT_COMPARE_MODE;
            
            /* Set the default capture mode defined in the parameter */
            ctrl = PulseCounter_CONTROL & ((uint8)(~PulseCounter_CTRL_CAPMODE_MASK));
            
            #if( 0 != PulseCounter_CAPTURE_MODE_CONF)
                PulseCounter_CONTROL = ctrl | PulseCounter_DEFAULT_CAPTURE_MODE;
            #else
                PulseCounter_CONTROL = ctrl;
            #endif /* 0 != PulseCounter_CAPTURE_MODE */ 
            
            #endif /* (!PulseCounter_ControlRegRemoved) */
        #endif /* (PulseCounter_UsingFixedFunction) */
        
        /* Clear all data in the FIFO's */
        #if (!PulseCounter_UsingFixedFunction)
            PulseCounter_ClearFIFO();
        #endif /* (!PulseCounter_UsingFixedFunction) */
        
        /* Set Initial values from Configuration */
        PulseCounter_WritePeriod(PulseCounter_INIT_PERIOD_VALUE);
        #if (!(PulseCounter_UsingFixedFunction && (CY_PSOC5A)))
            PulseCounter_WriteCounter(PulseCounter_INIT_COUNTER_VALUE);
        #endif /* (!(PulseCounter_UsingFixedFunction && (CY_PSOC5A))) */
        PulseCounter_SetInterruptMode(PulseCounter_INIT_INTERRUPTS_MASK);
        
        #if (!PulseCounter_UsingFixedFunction)
            /* Read the status register to clear the unwanted interrupts */
            (void)PulseCounter_ReadStatusRegister();
            /* Set the compare value (only available to non-fixed function implementation */
            PulseCounter_WriteCompare(PulseCounter_INIT_COMPARE_VALUE);
            /* Use the interrupt output of the status register for IRQ output */
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            PulseCounter_interruptState = CyEnterCriticalSection();
            
            PulseCounter_STATUS_AUX_CTRL |= PulseCounter_STATUS_ACTL_INT_EN_MASK;
            
            /* Exit Critical Region*/
            CyExitCriticalSection(PulseCounter_interruptState);
            
        #endif /* (!PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_Enable
********************************************************************************
* Summary:
*     Enable the Counter
* 
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: 
*   If the Enable mode is set to Hardware only then this function has no effect 
*   on the operation of the counter.
*
*******************************************************************************/
void PulseCounter_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (PulseCounter_UsingFixedFunction)
        PulseCounter_GLOBAL_ENABLE |= PulseCounter_BLOCK_EN_MASK;
        PulseCounter_GLOBAL_STBY_ENABLE |= PulseCounter_BLOCK_STBY_EN_MASK;
    #endif /* (PulseCounter_UsingFixedFunction) */  
        
    /* Enable the counter from the control register  */
    /* If Fixed Function then make sure Mode is set correctly */
    /* else make sure reset is clear */
    #if(!PulseCounter_ControlRegRemoved || PulseCounter_UsingFixedFunction)
        PulseCounter_CONTROL |= PulseCounter_CTRL_ENABLE;                
    #endif /* (!PulseCounter_ControlRegRemoved || PulseCounter_UsingFixedFunction) */
    
}


/*******************************************************************************
* Function Name: PulseCounter_Start
********************************************************************************
* Summary:
*  Enables the counter for operation 
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  PulseCounter_initVar: Is modified when this function is called for the  
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void PulseCounter_Start(void) 
{
    if(PulseCounter_initVar == 0u)
    {
        PulseCounter_Init();
        
        PulseCounter_initVar = 1u; /* Clear this bit for Initialization */        
    }
    
    /* Enable the Counter */
    PulseCounter_Enable();        
}


/*******************************************************************************
* Function Name: PulseCounter_Stop
********************************************************************************
* Summary:
* Halts the counter, but does not change any modes or disable interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects: If the Enable mode is set to Hardware only then this function
*               has no effect on the operation of the counter.
*
*******************************************************************************/
void PulseCounter_Stop(void) 
{
    /* Disable Counter */
    #if(!PulseCounter_ControlRegRemoved || PulseCounter_UsingFixedFunction)
        PulseCounter_CONTROL &= ((uint8)(~PulseCounter_CTRL_ENABLE));        
    #endif /* (!PulseCounter_ControlRegRemoved || PulseCounter_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (PulseCounter_UsingFixedFunction)
        PulseCounter_GLOBAL_ENABLE &= ((uint8)(~PulseCounter_BLOCK_EN_MASK));
        PulseCounter_GLOBAL_STBY_ENABLE &= ((uint8)(~PulseCounter_BLOCK_STBY_EN_MASK));
    #endif /* (PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_SetInterruptMode
********************************************************************************
* Summary:
* Configures which interrupt sources are enabled to generate the final interrupt
*
* Parameters:  
*  InterruptsMask: This parameter is an or'd collection of the status bits
*                   which will be allowed to generate the counters interrupt.   
*
* Return: 
*  void
*
*******************************************************************************/
void PulseCounter_SetInterruptMode(uint8 interruptsMask) 
{
    PulseCounter_STATUS_MASK = interruptsMask;
}


/*******************************************************************************
* Function Name: PulseCounter_ReadStatusRegister
********************************************************************************
* Summary:
*   Reads the status register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the status register
*
* Side Effects:
*   Status register bits may be clear on read. 
*
*******************************************************************************/
uint8   PulseCounter_ReadStatusRegister(void) 
{
    return PulseCounter_STATUS;
}


#if(!PulseCounter_ControlRegRemoved)
/*******************************************************************************
* Function Name: PulseCounter_ReadControlRegister
********************************************************************************
* Summary:
*   Reads the control register and returns it's state. This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
uint8   PulseCounter_ReadControlRegister(void) 
{
    return PulseCounter_CONTROL;
}


/*******************************************************************************
* Function Name: PulseCounter_WriteControlRegister
********************************************************************************
* Summary:
*   Sets the bit-field of the control register.  This function should use
*       defined types for the bit-field information as the bits in this
*       register may be permuteable.
*
* Parameters:  
*  void
*
* Return: 
*  (uint8) The contents of the control register
*
*******************************************************************************/
void    PulseCounter_WriteControlRegister(uint8 control) 
{
    PulseCounter_CONTROL = control;
}

#endif  /* (!PulseCounter_ControlRegRemoved) */


#if (!(PulseCounter_UsingFixedFunction && (CY_PSOC5A)))
/*******************************************************************************
* Function Name: PulseCounter_WriteCounter
********************************************************************************
* Summary:
*   This funtion is used to set the counter to a specific value
*
* Parameters:  
*  counter:  New counter value. 
*
* Return: 
*  void 
*
*******************************************************************************/
void PulseCounter_WriteCounter(uint32 counter) \
                                   
{
    #if(PulseCounter_UsingFixedFunction)
        /* assert if block is already enabled */
        CYASSERT (0u == (PulseCounter_GLOBAL_ENABLE & PulseCounter_BLOCK_EN_MASK));
        /* If block is disabled, enable it and then write the counter */
        PulseCounter_GLOBAL_ENABLE |= PulseCounter_BLOCK_EN_MASK;
        CY_SET_REG16(PulseCounter_COUNTER_LSB_PTR, (uint16)counter);
        PulseCounter_GLOBAL_ENABLE &= ((uint8)(~PulseCounter_BLOCK_EN_MASK));
    #else
        CY_SET_REG32(PulseCounter_COUNTER_LSB_PTR, counter);
    #endif /* (PulseCounter_UsingFixedFunction) */
}
#endif /* (!(PulseCounter_UsingFixedFunction && (CY_PSOC5A))) */


/*******************************************************************************
* Function Name: PulseCounter_ReadCounter
********************************************************************************
* Summary:
* Returns the current value of the counter.  It doesn't matter
* if the counter is enabled or running.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) The present value of the counter.
*
*******************************************************************************/
uint32 PulseCounter_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    #if(PulseCounter_UsingFixedFunction)
		(void)CY_GET_REG16(PulseCounter_COUNTER_LSB_PTR);
	#else
		(void)CY_GET_REG8(PulseCounter_COUNTER_LSB_PTR_8BIT);
	#endif/* (PulseCounter_UsingFixedFunction) */
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    #if(PulseCounter_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(PulseCounter_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG32(PulseCounter_STATICCOUNT_LSB_PTR));
    #endif /* (PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_ReadCapture
********************************************************************************
* Summary:
*   This function returns the last value captured.
*
* Parameters:  
*  void
*
* Return: 
*  (uint32) Present Capture value.
*
*******************************************************************************/
uint32 PulseCounter_ReadCapture(void) 
{
    #if(PulseCounter_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(PulseCounter_STATICCOUNT_LSB_PTR));
    #else
        return (CY_GET_REG32(PulseCounter_STATICCOUNT_LSB_PTR));
    #endif /* (PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_WritePeriod
********************************************************************************
* Summary:
* Changes the period of the counter.  The new period 
* will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period: (uint32) A value of 0 will result in
*         the counter remaining at zero.  
*
* Return: 
*  void
*
*******************************************************************************/
void PulseCounter_WritePeriod(uint32 period) 
{
    #if(PulseCounter_UsingFixedFunction)
        CY_SET_REG16(PulseCounter_PERIOD_LSB_PTR,(uint16)period);
    #else
        CY_SET_REG32(PulseCounter_PERIOD_LSB_PTR, period);
    #endif /* (PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_ReadPeriod
********************************************************************************
* Summary:
* Reads the current period value without affecting counter operation.
*
* Parameters:  
*  void:  
*
* Return: 
*  (uint32) Present period value.
*
*******************************************************************************/
uint32 PulseCounter_ReadPeriod(void) 
{
    #if(PulseCounter_UsingFixedFunction)
        return ((uint32)CY_GET_REG16(PulseCounter_PERIOD_LSB_PTR));
    #else
        return (CY_GET_REG32(PulseCounter_PERIOD_LSB_PTR));
    #endif /* (PulseCounter_UsingFixedFunction) */
}


#if (!PulseCounter_UsingFixedFunction)
/*******************************************************************************
* Function Name: PulseCounter_WriteCompare
********************************************************************************
* Summary:
* Changes the compare value.  The compare output will 
* reflect the new value on the next UDB clock.  The compare output will be 
* driven high when the present counter value compares true based on the 
* configured compare mode setting. 
*
* Parameters:  
*  Compare:  New compare value. 
*
* Return: 
*  void
*
*******************************************************************************/
void PulseCounter_WriteCompare(uint32 compare) \
                                   
{
    #if(PulseCounter_UsingFixedFunction)
        CY_SET_REG16(PulseCounter_COMPARE_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG32(PulseCounter_COMPARE_LSB_PTR, compare);
    #endif /* (PulseCounter_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: PulseCounter_ReadCompare
********************************************************************************
* Summary:
* Returns the compare value.
*
* Parameters:  
*  void:
*
* Return: 
*  (uint32) Present compare value.
*
*******************************************************************************/
uint32 PulseCounter_ReadCompare(void) 
{
    return (CY_GET_REG32(PulseCounter_COMPARE_LSB_PTR));
}


#if (PulseCounter_COMPARE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: PulseCounter_SetCompareMode
********************************************************************************
* Summary:
*  Sets the software controlled Compare Mode.
*
* Parameters:
*  compareMode:  Compare Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void PulseCounter_SetCompareMode(uint8 compareMode) 
{
    /* Clear the compare mode bits in the control register */
    PulseCounter_CONTROL &= ((uint8)(~PulseCounter_CTRL_CMPMODE_MASK));
    
    /* Write the new setting */
    PulseCounter_CONTROL |= compareMode;
}
#endif  /* (PulseCounter_COMPARE_MODE_SOFTWARE) */


#if (PulseCounter_CAPTURE_MODE_SOFTWARE)
/*******************************************************************************
* Function Name: PulseCounter_SetCaptureMode
********************************************************************************
* Summary:
*  Sets the software controlled Capture Mode.
*
* Parameters:
*  captureMode:  Capture Mode Enumerated Type.
*
* Return:
*  void
*
*******************************************************************************/
void PulseCounter_SetCaptureMode(uint8 captureMode) 
{
    /* Clear the capture mode bits in the control register */
    PulseCounter_CONTROL &= ((uint8)(~PulseCounter_CTRL_CAPMODE_MASK));
    
    /* Write the new setting */
    PulseCounter_CONTROL |= ((uint8)((uint8)captureMode << PulseCounter_CTRL_CAPMODE0_SHIFT));
}
#endif  /* (PulseCounter_CAPTURE_MODE_SOFTWARE) */


/*******************************************************************************
* Function Name: PulseCounter_ClearFIFO
********************************************************************************
* Summary:
*   This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void:
*
* Return: 
*  None
*
*******************************************************************************/
void PulseCounter_ClearFIFO(void) 
{

    while(0u != (PulseCounter_ReadStatusRegister() & PulseCounter_STATUS_FIFONEMP))
    {
        (void)PulseCounter_ReadCapture();
    }

}
#endif  /* (!PulseCounter_UsingFixedFunction) */


/* [] END OF FILE */

