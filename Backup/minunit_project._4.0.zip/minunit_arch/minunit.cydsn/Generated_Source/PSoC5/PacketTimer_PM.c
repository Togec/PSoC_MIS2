/*******************************************************************************
* File Name: PacketTimer_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "PacketTimer.h"

static PacketTimer_backupStruct PacketTimer_backup;


/*******************************************************************************
* Function Name: PacketTimer_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PacketTimer_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void PacketTimer_SaveConfig(void) 
{
    #if (!PacketTimer_UsingFixedFunction)
        PacketTimer_backup.TimerUdb = PacketTimer_ReadCounter();
        PacketTimer_backup.InterruptMaskValue = PacketTimer_STATUS_MASK;
        #if (PacketTimer_UsingHWCaptureCounter)
            PacketTimer_backup.TimerCaptureCounter = PacketTimer_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!PacketTimer_UDB_CONTROL_REG_REMOVED)
            PacketTimer_backup.TimerControlRegister = PacketTimer_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: PacketTimer_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PacketTimer_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PacketTimer_RestoreConfig(void) 
{   
    #if (!PacketTimer_UsingFixedFunction)

        PacketTimer_WriteCounter(PacketTimer_backup.TimerUdb);
        PacketTimer_STATUS_MASK =PacketTimer_backup.InterruptMaskValue;
        #if (PacketTimer_UsingHWCaptureCounter)
            PacketTimer_SetCaptureCount(PacketTimer_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!PacketTimer_UDB_CONTROL_REG_REMOVED)
            PacketTimer_WriteControlRegister(PacketTimer_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: PacketTimer_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PacketTimer_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void PacketTimer_Sleep(void) 
{
    #if(!PacketTimer_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(PacketTimer_CTRL_ENABLE == (PacketTimer_CONTROL & PacketTimer_CTRL_ENABLE))
        {
            /* Timer is enabled */
            PacketTimer_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            PacketTimer_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    PacketTimer_Stop();
    PacketTimer_SaveConfig();
}


/*******************************************************************************
* Function Name: PacketTimer_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PacketTimer_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PacketTimer_Wakeup(void) 
{
    PacketTimer_RestoreConfig();
    #if(!PacketTimer_UDB_CONTROL_REG_REMOVED)
        if(PacketTimer_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                PacketTimer_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
