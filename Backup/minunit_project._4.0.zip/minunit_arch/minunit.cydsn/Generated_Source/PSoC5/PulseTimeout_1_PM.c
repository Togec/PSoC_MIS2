/*******************************************************************************
* File Name: PulseTimeout_1_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "PulseTimeout_1.h"

static PulseTimeout_1_backupStruct PulseTimeout_1_backup;


/*******************************************************************************
* Function Name: PulseTimeout_1_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PulseTimeout_1_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void PulseTimeout_1_SaveConfig(void) 
{
    #if (!PulseTimeout_1_UsingFixedFunction)
        PulseTimeout_1_backup.TimerUdb = PulseTimeout_1_ReadCounter();
        PulseTimeout_1_backup.InterruptMaskValue = PulseTimeout_1_STATUS_MASK;
        #if (PulseTimeout_1_UsingHWCaptureCounter)
            PulseTimeout_1_backup.TimerCaptureCounter = PulseTimeout_1_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!PulseTimeout_1_UDB_CONTROL_REG_REMOVED)
            PulseTimeout_1_backup.TimerControlRegister = PulseTimeout_1_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: PulseTimeout_1_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PulseTimeout_1_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void PulseTimeout_1_RestoreConfig(void) 
{   
    #if (!PulseTimeout_1_UsingFixedFunction)

        PulseTimeout_1_WriteCounter(PulseTimeout_1_backup.TimerUdb);
        PulseTimeout_1_STATUS_MASK =PulseTimeout_1_backup.InterruptMaskValue;
        #if (PulseTimeout_1_UsingHWCaptureCounter)
            PulseTimeout_1_SetCaptureCount(PulseTimeout_1_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!PulseTimeout_1_UDB_CONTROL_REG_REMOVED)
            PulseTimeout_1_WriteControlRegister(PulseTimeout_1_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: PulseTimeout_1_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PulseTimeout_1_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void PulseTimeout_1_Sleep(void) 
{
    #if(!PulseTimeout_1_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(PulseTimeout_1_CTRL_ENABLE == (PulseTimeout_1_CONTROL & PulseTimeout_1_CTRL_ENABLE))
        {
            /* Timer is enabled */
            PulseTimeout_1_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            PulseTimeout_1_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    PulseTimeout_1_Stop();
    PulseTimeout_1_SaveConfig();
}


/*******************************************************************************
* Function Name: PulseTimeout_1_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  PulseTimeout_1_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void PulseTimeout_1_Wakeup(void) 
{
    PulseTimeout_1_RestoreConfig();
    #if(!PulseTimeout_1_UDB_CONTROL_REG_REMOVED)
        if(PulseTimeout_1_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                PulseTimeout_1_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
