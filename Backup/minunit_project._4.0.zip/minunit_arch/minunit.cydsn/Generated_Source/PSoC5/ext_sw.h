/*******************************************************************************
* File Name: ext_sw.h
* Version 1.80
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_AMUX_ext_sw_H)
#define CY_AMUX_ext_sw_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void ext_sw_Start(void) ;
#define ext_sw_Init() ext_sw_Start()
void ext_sw_FastSelect(uint8 channel) ;
/* The Stop, Select, Connect, Disconnect and DisconnectAll functions are declared elsewhere */
/* void ext_sw_Stop(void); */
/* void ext_sw_Select(uint8 channel); */
/* void ext_sw_Connect(uint8 channel); */
/* void ext_sw_Disconnect(uint8 channel); */
/* void ext_sw_DisconnectAll(void) */


/***************************************
*         Parameter Constants
***************************************/

#define ext_sw_CHANNELS  1u
#define ext_sw_MUXTYPE   1
#define ext_sw_ATMOSTONE 0

/***************************************
*             API Constants
***************************************/

#define ext_sw_NULL_CHANNEL 0xFFu
#define ext_sw_MUX_SINGLE   1
#define ext_sw_MUX_DIFF     2


/***************************************
*        Conditional Functions
***************************************/

#if ext_sw_MUXTYPE == ext_sw_MUX_SINGLE
# if !ext_sw_ATMOSTONE
#  define ext_sw_Connect(channel) ext_sw_Set(channel)
# endif
# define ext_sw_Disconnect(channel) ext_sw_Unset(channel)
#else
# if !ext_sw_ATMOSTONE
void ext_sw_Connect(uint8 channel) ;
# endif
void ext_sw_Disconnect(uint8 channel) ;
#endif

#if ext_sw_ATMOSTONE
# define ext_sw_Stop() ext_sw_DisconnectAll()
# define ext_sw_Select(channel) ext_sw_FastSelect(channel)
void ext_sw_DisconnectAll(void) ;
#else
# define ext_sw_Stop() ext_sw_Start()
void ext_sw_Select(uint8 channel) ;
# define ext_sw_DisconnectAll() ext_sw_Start()
#endif

#endif /* CY_AMUX_ext_sw_H */


/* [] END OF FILE */
