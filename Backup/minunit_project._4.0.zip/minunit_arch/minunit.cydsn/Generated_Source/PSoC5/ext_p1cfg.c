/*******************************************************************************
* File Name: ext_p1cfg.c
* Version 1.80
*
*  Description:
*    This file contains all functions required for the analog multiplexer
*    AMux User Module.
*
*   Note:
*
*******************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "ext_p1cfg.h"

static uint8 ext_p1cfg_lastChannel = ext_p1cfg_NULL_CHANNEL;


/*******************************************************************************
* Function Name: ext_p1cfg_Start
********************************************************************************
* Summary:
*  Disconnect all channels.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_Start(void) 
{
    uint8 chan;

    for(chan = 0u; chan < ext_p1cfg_CHANNELS ; chan++)
    {
#if (ext_p1cfg_MUXTYPE == ext_p1cfg_MUX_SINGLE)
        ext_p1cfg_Unset(chan);
#else
        ext_p1cfg_CYAMUXSIDE_A_Unset(chan);
        ext_p1cfg_CYAMUXSIDE_B_Unset(chan);
#endif
    }

    ext_p1cfg_lastChannel = ext_p1cfg_NULL_CHANNEL;
}


#if (!ext_p1cfg_ATMOSTONE)
/*******************************************************************************
* Function Name: ext_p1cfg_Select
********************************************************************************
* Summary:
*  This functions first disconnects all channels then connects the given
*  channel.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_Select(uint8 channel) 
{
    ext_p1cfg_DisconnectAll();        /* Disconnect all previous connections */
    ext_p1cfg_Connect(channel);       /* Make the given selection */
    ext_p1cfg_lastChannel = channel;  /* Update last channel */
}
#endif


/*******************************************************************************
* Function Name: ext_p1cfg_FastSelect
********************************************************************************
* Summary:
*  This function first disconnects the last connection made with FastSelect or
*  Select, then connects the given channel. The FastSelect function is similar
*  to the Select function, except it is faster since it only disconnects the
*  last channel selected rather than all channels.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_FastSelect(uint8 channel) 
{
    /* Disconnect the last valid channel */
    if( ext_p1cfg_lastChannel != ext_p1cfg_NULL_CHANNEL)
    {
        ext_p1cfg_Disconnect(ext_p1cfg_lastChannel);
    }

    /* Make the new channel connection */
#if (ext_p1cfg_MUXTYPE == ext_p1cfg_MUX_SINGLE)
    ext_p1cfg_Set(channel);
#else
    ext_p1cfg_CYAMUXSIDE_A_Set(channel);
    ext_p1cfg_CYAMUXSIDE_B_Set(channel);
#endif


    ext_p1cfg_lastChannel = channel;   /* Update last channel */
}


#if (ext_p1cfg_MUXTYPE == ext_p1cfg_MUX_DIFF)
#if (!ext_p1cfg_ATMOSTONE)
/*******************************************************************************
* Function Name: ext_p1cfg_Connect
********************************************************************************
* Summary:
*  This function connects the given channel without affecting other connections.
*
* Parameters:
*  channel:  The channel to connect to the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_Connect(uint8 channel) 
{
    ext_p1cfg_CYAMUXSIDE_A_Set(channel);
    ext_p1cfg_CYAMUXSIDE_B_Set(channel);
}
#endif

/*******************************************************************************
* Function Name: ext_p1cfg_Disconnect
********************************************************************************
* Summary:
*  This function disconnects the given channel from the common or output
*  terminal without affecting other connections.
*
* Parameters:
*  channel:  The channel to disconnect from the common terminal.
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_Disconnect(uint8 channel) 
{
    ext_p1cfg_CYAMUXSIDE_A_Unset(channel);
    ext_p1cfg_CYAMUXSIDE_B_Unset(channel);
}
#endif

#if (ext_p1cfg_ATMOSTONE)
/*******************************************************************************
* Function Name: ext_p1cfg_DisconnectAll
********************************************************************************
* Summary:
*  This function disconnects all channels.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void ext_p1cfg_DisconnectAll(void) 
{
    if(ext_p1cfg_lastChannel != ext_p1cfg_NULL_CHANNEL) 
    {
        ext_p1cfg_Disconnect(ext_p1cfg_lastChannel);
        ext_p1cfg_lastChannel = ext_p1cfg_NULL_CHANNEL;
    }
}
#endif

/* [] END OF FILE */
