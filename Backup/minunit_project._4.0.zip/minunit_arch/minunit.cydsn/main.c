/******************************************************************************
* Project Name		: MinUnit -- a minimal unit testing framework for C
* File Name			: main.c
* Version 			: **
* Device Used		: CY8C5888LTI-LP097
* Software Used		: PSoC Creator 3.1 SP2
* Compiler    		: ARM GCC 4.8.4, ARM RVDS Generic, ARM MDK Generic
* Related Hardware	: CY8CKIT059 PSoC 5 LP Prototyping Kit 
*******************************************************************************/

#include <device.h>
#include "stdio.h"
#include "assert.h"
#include "mbus.h"

char txt[500];

void test_X10(void)
{
 do
    {
        if (SW1_Read() == 0)
        {

            
            LED1_Write(1);
            
            //ext_mode_Connect(0);
           //ext_sw_Connect(0);

            if (0 == mbus_snd_nke(0xFE))
            {
                LED1_Write(0);
                CyDelay(500);
                LED1_Write(1);
                CyDelay(100);
            }
            LED1_Write(0);
            

            sprintf(txt, "SND_NKE mbus_repeat_count = %d, expected 1", mbus_repeat_count);
            assert(1 == mbus_repeat_count, txt);
            sprintf(txt, "SND_NKE mbus_rx_count = %d, expected 1", mbus_rx_count);
            assert(1 == mbus_rx_count, txt);
            sprintf(txt, "SND_NKE uart2_tx_buffer[0] = %%.2X, expected E5", mbus_rx_count);
            assert(0xE5 == uart2_rx_buffer[0], txt);
            //(float)(mbus_tmr_start/1000.0 - mbus_tmr_stop/1000.0)
            sprintf(txt, "SND_NKE slave wait time = %ld us, expected between 11 bit times and (330 bit times + 50ms) ", (mbus_tmr_start - mbus_tmr_stop));
            assert(MAX_WAIT_TIME > (mbus_tmr_start - mbus_tmr_stop), txt);
            
            int rez = mbus_request_respond(0xFE);
            if (0 != rez)
            {
                LED1_Write(0);
                CyDelay(500);
                LED1_Write(1);
                CyDelay(100);
            }
            LED1_Write(0);
            int txt_lenght = 0;
            txt_lenght += sprintf((char *)&txt[txt_lenght], "REQ_RSP ");
            int i;
            for (i = 0; i < mbus_rx_count; i++)
            {
                txt_lenght += sprintf((char *)&txt[txt_lenght], "%.2X ", uart2_rx_buffer[i]);
            }
            assert(0 != rez, txt);
            if (0 == rez)
            {
               assert((mbus_rx_count > 9), "REQ_RSP (mbus_rx_count > 9)");
               assert((0x68 == uart2_rx_buffer[0]), "REQ_RSP (0x68 == uart2_rx_buffer[0])");
               assert((uart2_rx_buffer[1] == uart2_rx_buffer[2]), "REQ_RSP (uart2_rx_buffer[1] == uart2_rx_buffer[2])");
               assert((0x68 == uart2_rx_buffer[3]), "REQ_RSP (0x68 == uart2_rx_buffer[3])");
               assert((mbus_rx_count == uart2_rx_buffer[1]+6), "REQ_RSP (mbus_rx_count == uart2_rx_buffer[1]+6)");
            
               sprintf(txt, "REQ_RSP (mbus_cs((uint8 *)&uart2_rx_buffer[4], uart2_rx_buffer[1]) == uart2_rx_buffer[4+uart2_rx_buffer[1]]) => %.2X  == %.2X", mbus_cs((uint8 *)&uart2_rx_buffer[4], uart2_rx_buffer[1]-1), uart2_rx_buffer[4+uart2_rx_buffer[1]]);
               assert((mbus_cs((uint8 *)uart2_rx_buffer[4], uart2_rx_buffer[1]) == uart2_rx_buffer[5+uart2_rx_buffer[1]]), txt);
               assert((0x16 == uart2_rx_buffer[5+uart2_rx_buffer[1]]), "REQ_RSP (0x16 == uart2_rx_buffer[5+uart2_rx_buffer[1]])");
            }
            
            sprintf(txt, "REQ_RSP mbus_repeat_count = %d, expected 1", mbus_repeat_count);
            assert(1 == mbus_repeat_count, txt);
            
            //(float)(mbus_tmr_start/1000.0 - mbus_tmr_stop/1000.0)
            sprintf(txt, "REQ_RSP slave wait time = %ld us, expected between 11 bit times and (330 bit times + 50ms) ", (mbus_tmr_start - mbus_tmr_stop));
            assert(MAX_WAIT_TIME > (mbus_tmr_start - mbus_tmr_stop), txt);
            
            sprintf(txt, "REQ_RSP mbus_bit_max = %ld us, expected < 4583*1.2 (2400bps)", mbus_bit_max);
            assert(MAX_BIT_TIME >= mbus_bit_max, txt);
            
            sprintf(txt, "REQ_RSP mbus_bit_min = %ld us, expected  > 4583*0.8 (2400bps)", mbus_bit_min);
            assert(MIN_BIT_TIME <= mbus_bit_min, txt);

        }
        else
        {
            //ext_mode_Disconnect(0);
            //ext_sw_Disconnect(0);
            LED1_Write(0);
        }
      
    }
    while (1);
}

#define MIS_RST0 (1)
#define MIS_RST  (2)
#define MIS_CTRL (4)

void mist_start(void)
{
    MIS_Reg_Write(MIS_RST0 + MIS_RST);
    CyDelay(1);
    PacketTimer_ClearFIFO();
    PulseCounter_WriteCounter(0);
    MIS_Reg_Write(0);
}

void mis_stop(void)
{
    MIS_Reg_Write(MIS_RST);
    CyDelay(1);
    MIS_Reg_Write(MIS_RST + MIS_CTRL);
    CyDelay(1);
    MIS_Reg_Write(MIS_CTRL);
}

uint32 PacketTimerStart;
uint32 PacketTimerStop;
uint32 PulseCounterTotTime;

void mis_measure(uint32 time_ms)
{
    mist_start();
    while (0 == MIS_Stat_Read());
    
    CyDelay(time_ms);
    
    mis_stop();
    while (0 == MIS_Stat_Read());
    
    //ar fifo 2 reiksmes? - klaidos pozymis
    
    PacketTimerStart = PacketTimer_ReadCapture();
    PacketTimerStop = PacketTimer_ReadCapture();
    PulseCounterTotTime = PacketTimerStart - PacketTimerStop;
}

void test_X4(void)
{
    //test jumper ON
    CyDelay(2000);
    mode1_Write(0);
    CyDelay(5000);
    LED1_Write(1);
    CyDelay(100);
    LED1_Write(0);
    uint8 uart2_tx_buffer[500];
    do
    {
        mis_measure(10000);
        sprintf(txt, "MIS PulseCounter = %ld TotTime = %ld", PulseCounter_ReadCounter(), PulseCounterTotTime);
        assert(0 == 0, txt);
    }
    while (1);
}


int main()
{    
    /* Start the components */
    UART_1_Start();
    UART_2_Start();
    
    PulseTimeout_Start();
    PacketTimer_Start();
    PulseCounter_Start();
    
    //Stop_Packet_Timer_Stop();
    
    

    
    ext_sw_Start();
    //ext_mode_Start();
    
    /* Turn OFF batteries*/
    Vbat_r_Write(1);
    Vbat_Write(1);
      
    /* Send message to verify COM port is connected properly */
    //http://wiki.bash-hackers.org/scripting/terminalcodes
    
    UART_1_PutString("\x1b[2J\x1b[H"); //erase screen and go home
    UART_1_PutString("A minimal unit testing framework for C\r\n\r\n");
    /* Turn ON batteries*/
    Vbat_r_Write(0);
    Vbat_Write(0);
    //Build Stteing/Linker/General and : Use newlib-nano = FALSE
    //test_X10();
    test_X4();
}

/* [] END OF FILE */
